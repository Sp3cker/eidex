import speciesDataJson from "./speciesData.json" with { type: "json" };



export interface Pokemon {
  speciesId: number;
  speciesName: string;
  types: number[];
  stats: number[];
  abilities: number[];
  heldItems?: number[];
  levelUpMoves: number[][];
  tmMoves?: number[];
  eggMoves?: number[] | null;
  dexId: number;
  evolutions?: number[][] | null;
  forms: string[] | null;
  formId?: number;
  nameKey: string;
  siblings?: number[];
  baseForm?: number;
  tutorMoves?: number[];
  items?: number[];
  eggGroup?: number[];
  ancestor?: number;
  order?: number;

  // Legacy properties for compatibility
  index?: number;
}

/**
 * Lookup [id] to species data as a Map for O(1) access
 * Excludes Gmax forms like pokemonData array
 */
export const pokemonDataMap = new Map<string, Pokemon>(
  Object.entries(speciesDataJson)
    .filter(([_, pokemon]) => !pokemon.nameKey.includes("Gmax"))
    .map(
      ([key, pokemon]) =>
        [
          key,
          {
            ...pokemon,
            forms: Array.isArray(pokemon.forms)
              ? pokemon.forms.flat().map(String)
              : [],
          },
        ] as [string, Pokemon]
    )
);

export const pokemonData: Pokemon[] = Object.values(speciesDataJson)
  .filter((p) => p.nameKey.includes("Gmax") === false)
  .map((p) => ({
    ...p,
    forms: Array.isArray(p.forms) ? p.forms.flat().map(String) : [],
  }));

// --- PRE-EVOLUTION (CHILD -> PARENT) LOOKUP ---
