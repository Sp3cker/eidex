import { extractTrainerIdFromFile } from "./randomiser/trainerIdExtractor.ts";
import { calculateRandomizedEncounter } from "./randomiser/encounterRandomiser.ts";

// Adjust path to your save
const savePath = Deno.args[0];
if (!savePath) {
  console.error("Usage: deno run --allow-read testRandomize.ts <savefile.sav>");
  Deno.exit(1);
}

const { trainerId, fullId, secretId } = await extractTrainerIdFromFile(savePath);
console.log("Trainer IDs", { trainerId, secretId, fullId });

// Example parameters (adjust area/slot species as per test case)
const originalSpecies = 16; // user test species
const baseMap = "MAP_ROUTE101"; // adjust if needed
const levelId = "MAP_ROUTE101"; // adjust if needed
const area = 0; // Land

const result = calculateRandomizedEncounter(originalSpecies, baseMap, levelId, area, fullId);
console.log(`Original ${originalSpecies} -> Randomized ${result}`);
