import randomData from "./randomize.json" with { type: "json" }
interface SpeciesEntry { ID: number; baseStat: number; isLegendary?: boolean; mode?: number }
const species: SpeciesEntry[] = randomData as unknown as SpeciesEntry[];
if (!Array.isArray(species)) {
  console.error("randomize.json is not an array");
  Deno.exit(1);
}
const ids = new Set<number>();
const duplicates: number[] = [];
for (const s of species) {
  if (ids.has(s.ID)) duplicates.push(s.ID); else ids.add(s.ID);
}
const maxId = Math.max(...ids);
const minId = Math.min(...ids);
const EXPECTED_MAX = 1534;
const missing: number[] = [];
for (let i = 0; i <= EXPECTED_MAX; i++) if (!ids.has(i)) missing.push(i);
const invalidBaseStat = [...ids].filter(id => id !== 0 && species.find(s=>s.ID===id)?.baseStat === 0);
console.log(JSON.stringify({
  count: species.length,
  minId,
  maxId,
  expectedMax: EXPECTED_MAX,
  missingCount: missing.length,
  sampleMissing: missing.slice(0,20),
  duplicates,
  invalidBaseStatCount: invalidBaseStat.length,
  invalidBaseStatSample: invalidBaseStat.slice(0,20)
}, null, 2));
