import randoSeeds from "../randomize.json" with { type: "json" }

interface SpeciesRandomizations {
  id: number;
  isLegendary?: boolean;
  mode: number; // per-species randomizer mode (form behavior / validity)
  baseStat: number;
}

// Per-species randomizer mode constants (from C enum)
export enum RandomizerPerSpeciesMode {
  MON_RANDOMIZER_NORMAL = 0,
  MON_RANDOMIZER_RANDOM_FORM = 1,
  MON_RANDOMIZER_SPECIAL_FORM = 2,
  MON_RANDOMIZER_INVALID = 3,
}

const RANDOMIZER_SPECIES_COUNT = 1535;
const GROUP_INVALID = 0xFFFF;

export enum RandomizerSpeciesMode {
  MON_RANDOM = 0,
  MON_RANDOM_LEGEND_AWARE = 1,
  MON_RANDOM_BST = 2,
  MON_EVOLUTION = 3,
  MAX_MON_MODE = 4,
}

interface RandomizeJsonEntry { ID: number; baseStat: number; isLegendary?: boolean; mode: number }

const speciesById: SpeciesRandomizations[] = (() => {
  const arr: SpeciesRandomizations[] = new Array(RANDOMIZER_SPECIES_COUNT);
  const sentinel: SpeciesRandomizations = { id: 0, isLegendary: false, mode: RandomizerPerSpeciesMode.MON_RANDOMIZER_INVALID, baseStat: 0 };
  for (let i = 0; i < RANDOMIZER_SPECIES_COUNT; i++) arr[i] = { ...sentinel, id: i };
  const src: RandomizeJsonEntry[] = randoSeeds as unknown as RandomizeJsonEntry[];
  for (const entry of src) {
    const speciesId = entry.ID;
    if (speciesId >= 0 && speciesId < RANDOMIZER_SPECIES_COUNT) {
      arr[speciesId] = { id: speciesId, isLegendary: entry.isLegendary, mode: entry.mode, baseStat: entry.baseStat };
    }
  }
  return arr;
})();

export interface SpeciesDataTable {
  groupData: number[];              // Sorted groups (after heap sort)
  groupIndexToSpecies: number[];    // Maps sorted index -> species ID
  speciesToGroupIndex: number[];    // Maps species ID -> sorted index
}

function isSpeciesPermitted(speciesId: number): boolean {
  if (speciesId === 0) return false; // SPECIES_NONE
  const info = speciesById[speciesId];
  if (!info) return false;
  if (info.mode === RandomizerPerSpeciesMode.MON_RANDOMIZER_INVALID) return false;
  if (info.baseStat === 0) return false; // disabled placeholder
  return true;
}

function leftChildIndex(index: number): number {
  return 2 * index + 1;
}

function swapSpeciesAndGroup(table: SpeciesDataTable, indexA: number, indexB: number): void {
  const tempGroup = table.groupData[indexA];
  table.groupData[indexA] = table.groupData[indexB];
  table.groupData[indexB] = tempGroup;
  const tempSpecies = table.groupIndexToSpecies[indexA];
  table.groupIndexToSpecies[indexA] = table.groupIndexToSpecies[indexB];
  table.groupIndexToSpecies[indexB] = tempSpecies;
}

// Fillers replicating C logic
function fillSpeciesGroupsRandom(table: SpeciesDataTable): void {
  for (let i = 0; i < RANDOMIZER_SPECIES_COUNT; i++) {
    table.groupIndexToSpecies[i] = i;
    table.groupData[i] = isSpeciesPermitted(i) ? 0 : GROUP_INVALID;
  }
}

function fillSpeciesGroupsLegendary(table: SpeciesDataTable): void {
  for (let i = 0; i < RANDOMIZER_SPECIES_COUNT; i++) {
    table.groupIndexToSpecies[i] = i;
    table.groupData[i] = isSpeciesPermitted(i) ? (speciesById[i].isLegendary ? 1 : 0) : GROUP_INVALID;
  }
}

function fillSpeciesGroupsBST(table: SpeciesDataTable): void {
  for (let i = 0; i < RANDOMIZER_SPECIES_COUNT; i++) {
    table.groupIndexToSpecies[i] = i;
    table.groupData[i] = isSpeciesPermitted(i) ? speciesById[i].baseStat : GROUP_INVALID;
  }
}

// Placeholder evolution grouping (TODO: implement real evolutionary stage computation)
function fillSpeciesGroupsEvolution(table: SpeciesDataTable): void {
  // For now group everything permitted into stage 0 (acts similar to MON_RANDOM but leaves room for later stages)
  for (let i = 0; i < RANDOMIZER_SPECIES_COUNT; i++) {
    table.groupIndexToSpecies[i] = i;
    table.groupData[i] = isSpeciesPermitted(i) ? 0 : GROUP_INVALID;
  }
}

// Cache built tables per mode
const speciesTableCache = new Map<number, SpeciesDataTable>();

export function buildSpeciesTable(mode: RandomizerSpeciesMode): SpeciesDataTable {
  // Clamp invalid modes to MON_RANDOM as C does
  if (mode >= RandomizerSpeciesMode.MAX_MON_MODE) mode = RandomizerSpeciesMode.MON_RANDOM;

  const cached = speciesTableCache.get(mode);
  if (cached) return cached;

  if (speciesById.length !== RANDOMIZER_SPECIES_COUNT) {
    throw new Error(`Expected ${RANDOMIZER_SPECIES_COUNT} species, got ${speciesById.length}`);
  }

  const table: SpeciesDataTable = {
    groupData: new Array(RANDOMIZER_SPECIES_COUNT),
    groupIndexToSpecies: new Array(RANDOMIZER_SPECIES_COUNT),
    speciesToGroupIndex: new Array(RANDOMIZER_SPECIES_COUNT).fill(0),
  };

  switch (mode) {
    case RandomizerSpeciesMode.MON_RANDOM_LEGEND_AWARE:
      fillSpeciesGroupsLegendary(table);
      break;
    case RandomizerSpeciesMode.MON_RANDOM_BST:
      fillSpeciesGroupsBST(table);
      break;
    case RandomizerSpeciesMode.MON_EVOLUTION:
      fillSpeciesGroupsEvolution(table); // TODO real evolution stage grouping
      break;
    case RandomizerSpeciesMode.MON_RANDOM:
    default:
      fillSpeciesGroupsRandom(table);
  }

  // Heap sort (descending by group value) – mirrors C implementation
  let start = Math.floor(RANDOMIZER_SPECIES_COUNT / 2);
  let end = RANDOMIZER_SPECIES_COUNT - 1;
  while (end > 1) {
    if (start > 0) {
      start -= 1;
    } else {
      end -= 1;
      swapSpeciesAndGroup(table, end, 0);
    }
    let root = start;
    while (leftChildIndex(root) < end) {
      let child = leftChildIndex(root);
      if (child + 1 < end && table.groupData[child] < table.groupData[child + 1]) {
        child += 1;
      }
      if (table.groupData[root] < table.groupData[child]) {
        swapSpeciesAndGroup(table, root, child);
        root = child;
      } else {
        break;
      }
    }
  }

  // Build reverse lookup
  for (let i = 0; i < RANDOMIZER_SPECIES_COUNT; i++) {
    const speciesId = table.groupIndexToSpecies[i];
    if (speciesId >= 0 && speciesId < RANDOMIZER_SPECIES_COUNT) {
      table.speciesToGroupIndex[speciesId] = i;
    }
  }

  speciesTableCache.set(mode, table);
  return table;
}
