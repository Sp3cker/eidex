import { calculateRandomizedEncounter } from "./randomiser/encounterRandomiser.ts";
const ID = {
  fullId: -1716499767,
  secretId: 39344,
  sectorIndex: 2,
  trainerId: 19145,
};
(() => {
  const originalSpecies = 16; // Example: Pikachu
  const baseMap = "MAP_ROUTE101";
  const levelId = "MAP_ROUTE101";
  const area = 0; // Example area
  const trainerId = ID.trainerId; // Example trainer ID

  const randomizedSpecies = calculateRandomizedEncounter(
    originalSpecies,
    baseMap,
    levelId,
    area,
    trainerId
  );
  console.log(`Randomized Species ID: ${randomizedSpecies}`);
})();
